import React from 'react';

function BlogTitle() {
  return (
    <div className="back_re">
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    <div className="title">
                        <h2>BLOG</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}

export default BlogTitle
