import React from 'react'

function vnpay() {
  return (
    <div>vnpay</div>
  )
}

export default vnpay