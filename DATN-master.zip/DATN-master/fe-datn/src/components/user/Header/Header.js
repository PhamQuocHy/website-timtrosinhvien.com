 import React from 'react';
import HeaderContainer from './HeaderContainer';

function Header() {
  return (
      <div className="header">
          <HeaderContainer /> 
        </div>
      
  )
}

export default Header